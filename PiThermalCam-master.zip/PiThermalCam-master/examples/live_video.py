import pithermalcam as ptc

# Run this file locally to display the video feed live on screen
ptc.display_camera_live()
