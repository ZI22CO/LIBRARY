import pithermalcam as ptc

# Run a camera test, getting the mean temperature back
ptc.test_camera()
